# Link Shortener

A modern, responsive link shortener web application built with React and Vite. This application allows you to shorten long URLs into more manageable, shareable links with user authentication, custom short codes, and QR code generation.

## Features

- 🔗 **URL Shortening**: Convert long URLs into short, shareable links
- 👤 **User Authentication**: Secure signup/login system with user accounts
- 🎯 **Custom Short Codes**: Create personalized short codes or use auto-generated ones
- 📱 **QR Code Generation**: Generate and download QR codes for your shortened links
- 📋 **Copy to Clipboard**: One-click copying of shortened URLs
- 📊 **Click Tracking**: Track how many times your shortened links are clicked
- 📚 **Personal History**: Each user has their own private collection of shortened URLs
- 💾 **Local Storage**: Your data is saved locally in your browser
- 🗑️ **URL Management**: Delete unwanted shortened URLs
- 🌐 **URL Validation**: Automatic URL validation and protocol addition
- 📱 **Responsive Design**: Works perfectly on desktop and mobile devices
- 🌙 **Dark/Light Mode**: Automatic theme switching based on system preference

## Getting Started

### Prerequisites

Make sure you have Node.js installed on your system. You can download it from [nodejs.org](https://nodejs.org/).

### Installation

1. **Navigate to the project directory:**
   ```bash
   cd C:\Users\Q.V\link-shortener
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```
   
   **Or run the provided batch file:**
   ```bash
   install-qr-dependency.bat
   ```

3. **Start the development server:**
   ```bash
   npm run dev
   ```

4. **Open your browser and visit:**
   ```
   http://localhost:3000
   ```

### Available Scripts

- `npm run dev` - Start the development server
- `npm run build` - Build the project for production
- `npm run preview` - Preview the production build
- `npm run lint` - Run ESLint to check for code issues

## Usage

### Getting Started

1. **Create an Account:**
   - Click "Login / Sign Up" button
   - Choose "Sign Up" to create a new account
   - Enter a username (min 3 characters) and password (min 6 characters)
   - Or choose "Sign In" if you already have an account

2. **Shorten a URL:**
   - Enter a long URL in the main input field
   - Optionally enter a custom short code (3-20 characters, letters and numbers only)
   - Click "Shorten URL" button
   - Your shortened URL will appear in your personal history

### Managing Your Links

3. **Copy shortened URL:**
   - Click the copy button next to any shortened URL
   - The URL will be copied to your clipboard

4. **Generate QR Code:**
   - Click the QR code button next to any shortened URL
   - View the QR code in a popup modal
   - Download the QR code as a PNG image

5. **Visit original URL:**
   - Click the external link button to visit the original URL
   - This will also increment the click counter

6. **Delete URLs:**
   - Click the trash button to delete any shortened URL
   - Confirm the deletion in the popup dialog

7. **Account Management:**
   - Your username is displayed in the header when logged in
   - Click "Logout" to sign out and clear your session
   - Each user has their own private collection of shortened URLs

## Technical Details

### Built With

- **React 18** - Frontend framework
- **Vite** - Build tool and development server
- **Lucide React** - Icon library
- **React QR Code** - QR code generation
- **CSS3** - Styling with modern features
- **Local Storage** - Data persistence and user management

### Project Structure

```
link-shortener/
├── public/
├── src/
│   ├── components/
│   │   ├── AuthModal.jsx     # Authentication modal
│   │   ├── LoginForm.jsx     # Login form component
│   │   ├── SignupForm.jsx    # Signup form component
│   │   └── QRCodeDisplay.jsx # QR code generation and display
│   ├── contexts/
│   │   └── AuthContext.jsx   # User authentication context
│   ├── App.jsx              # Main application component
│   ├── App.css              # Application styles
│   ├── main.jsx             # Application entry point
│   └── index.css            # Global styles
├── index.html               # HTML template
├── package.json             # Dependencies and scripts
├── vite.config.js           # Vite configuration
├── install-qr-dependency.bat # Dependency installation script
└── README.md               # This file
```

### Features Explained

- **User Authentication**: Simple username/password system with data stored locally
- **Custom Short Codes**: Users can specify their own short codes (3-20 characters, alphanumeric)
- **QR Code Generation**: Creates downloadable QR codes for each shortened URL
- **URL Validation**: The app automatically validates URLs and adds `https://` protocol if missing
- **Random Short Codes**: Generates 6-character random codes using alphanumeric characters when no custom code is provided
- **Click Tracking**: Simulates real click tracking by incrementing counters
- **User-specific Data**: Each user has their own private collection of shortened URLs
- **Responsive Design**: Uses CSS Grid and Flexbox for responsive layouts
- **Accessibility**: Includes proper ARIA labels and keyboard navigation

## Visual Studio Integration

This project is fully compatible with Visual Studio Code and Visual Studio. Here's how to set it up:

### Visual Studio Code

1. **Open the project:**
   - File → Open Folder → Select `C:\Users\Q.V\link-shortener`

2. **Recommended Extensions:**
   - ES7+ React/Redux/React-Native snippets
   - Prettier - Code formatter
   - ESLint
   - Auto Rename Tag
   - Bracket Pair Colorizer

3. **Integrated Terminal:**
   - Use Ctrl+` to open the integrated terminal
   - Run `npm run dev` to start the development server

### Visual Studio (with Node.js tools)

1. **Open as Node.js project:**
   - File → Open → Folder → Select `C:\Users\Q.V\link-shortener`

2. **Configure startup:**
   - Right-click package.json → Set as startup file
   - Or use the integrated terminal to run `npm run dev`

## Customization

### Changing the Short URL Domain

Edit the `shortUrl` generation in `src/App.jsx`:

```javascript
const shortUrl = `https://your-domain.com/${shortCode}`
```

### Modifying Short Code Length

Change the loop count in the `generateShortCode` function:

```javascript
for (let i = 0; i < 8; i++) { // Change 6 to desired length
```

### Styling

- Modify `src/App.css` for component-specific styles
- Modify `src/index.css` for global styles
- The app supports both light and dark themes automatically

## Browser Compatibility

- Chrome 88+
- Firefox 85+
- Safari 14+
- Edge 88+

## License

This project is open source and available under the [MIT License](LICENSE).

## Contributing

Feel free to submit issues and enhancement requests!

## Support

If you encounter any issues or have questions, please check the browser console for error messages and ensure all dependencies are properly installed.